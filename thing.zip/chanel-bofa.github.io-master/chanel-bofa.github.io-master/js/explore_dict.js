var explore_dict = {'21': [
							["Technical development Lead", "Business Analyst", "Technical Analyst"],
							["SQA Lead", "SQA Senior Lead", "SQA Manager" ,"SQA Senior Manager"],
							["Operations", "Business", "Enterprise Data Management", "Chief Technology Office"]
						]
					}